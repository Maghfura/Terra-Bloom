import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, TreePine, Users } from "lucide-react";

const Community = () => {
  return (
    <section className="py-20 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          {/* Left: Blog & Impact */}
          <div className="space-y-8">
            {/* Blog Snippet */}
            <div className="bg-card rounded-2xl p-8 shadow-soft">
              <div className="inline-block px-3 py-1 rounded-full bg-primary/10 text-primary text-sm font-medium mb-4">
                Latest Article
              </div>
              <h3 className="text-2xl font-serif font-bold text-foreground mb-3">
                Sustainable Living: Small Swaps That Matter
              </h3>
              <p className="text-muted-foreground mb-6">
                Discover simple changes you can make today to reduce your environmental footprint and support ethical businesses.
              </p>
              <Link to="/blog">
                <Button variant="outline" className="group">
                  Read More
                  <ArrowRight className="ml-2 h-4 w-4 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
            </div>

            {/* TerraBloom Pledge */}
            <div className="bg-card rounded-2xl p-8 shadow-soft border-2 border-primary/20">
              <div className="flex items-start space-x-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <TreePine className="h-6 w-6 text-primary" />
                </div>
                <div>
                  <h4 className="text-lg font-semibold text-foreground mb-2">
                    TerraBloom Pledge
                  </h4>
                  <p className="text-muted-foreground">
                    A portion of every purchase supports reforestation projects and artisan co-ops worldwide.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* Right: Testimonial */}
          <div className="relative">
            <div className="bg-card rounded-2xl p-10 shadow-lift">
              <div className="flex items-start space-x-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Users className="h-8 w-8 text-primary" />
                </div>
                <div>
                  <h3 className="text-2xl font-serif font-bold text-foreground mb-2">
                    Join Our Community
                  </h3>
                  <p className="text-muted-foreground">
                    Thousands of conscious consumers making a difference
                  </p>
                </div>
              </div>
              
              <blockquote className="space-y-4">
                <p className="text-lg text-foreground italic">
                  "TerraBloom helped me transform my home into a sustainable sanctuary. Every product is thoughtfully crafted and the quality is exceptional."
                </p>
                <footer className="flex items-center space-x-3">
                  <div className="w-10 h-10 rounded-full bg-secondary" />
                  <div>
                    <p className="font-semibold text-foreground">Sarah Mitchell</p>
                    <p className="text-sm text-muted-foreground">Portland, OR</p>
                  </div>
                </footer>
              </blockquote>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-4 mt-8 pt-8 border-t border-border">
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">5,000+</div>
                  <div className="text-sm text-muted-foreground">Products</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">50K+</div>
                  <div className="text-sm text-muted-foreground">Happy Customers</div>
                </div>
                <div className="text-center">
                  <div className="text-2xl font-bold text-primary">100+</div>
                  <div className="text-sm text-muted-foreground">Artisans</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Community;
