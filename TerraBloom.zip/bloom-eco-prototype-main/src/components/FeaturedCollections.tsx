import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";

const collections = [
  {
    name: "Home & Garden Essentials",
    description: "Terracotta planters, organic seeds, natural decor",
    image: "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=800&q=80",
    href: "/collections/home-garden",
  },
  {
    name: "Artisan Skincare",
    description: "Handmade soaps, natural lotions, pure oils",
    image: "https://images.unsplash.com/photo-1556228578-8c89e6adf883?w=800&q=80",
    href: "/collections/personal-care",
  },
  {
    name: "Mindful Living",
    description: "Meditation cushions, organic incense, wellness",
    image: "https://images.unsplash.com/photo-1506126613408-eca07ce68773?w=800&q=80",
    href: "/collections/artisan-crafts",
  },
  {
    name: "Sustainable Fashion",
    description: "Organic cotton, recycled materials, ethical style",
    image: "https://images.unsplash.com/photo-1523381210434-271e8be1f52b?w=800&q=80",
    href: "/collections/eco-apparel",
  },
];

const FeaturedCollections = () => {
  return (
    <section className="py-20 bg-background">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
            Featured Collections
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Explore our curated selection of sustainable, handcrafted products.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {collections.map((collection, index) => (
            <Link
              key={index}
              to={collection.href}
              className="group relative overflow-hidden rounded-2xl shadow-soft hover:shadow-lift transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="aspect-[3/4] overflow-hidden">
                <img
                  src={collection.image}
                  alt={collection.name}
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <div className="absolute inset-0 bg-gradient-to-t from-foreground/80 via-foreground/40 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 text-white">
                <h3 className="text-xl font-semibold mb-2">{collection.name}</h3>
                <p className="text-sm text-white/90 mb-4">{collection.description}</p>
                <Button
                  variant="secondary"
                  size="sm"
                  className="group-hover:translate-x-1 transition-transform"
                >
                  View Collection
                  <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              </div>
            </Link>
          ))}
        </div>
      </div>
    </section>
  );
};

export default FeaturedCollections;
