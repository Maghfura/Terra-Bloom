import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardFooter } from "@/components/ui/card";

const products = [
  {
    id: 1,
    name: "Organic Cotton T-Shirt",
    price: "$32",
    image: "https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400&h=500&fit=crop",
    description: "100% organic cotton, ethically made"
  },
  {
    id: 2,
    name: "Recycled Denim Jacket",
    price: "$89",
    image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?w=400&h=500&fit=crop",
    description: "Made from recycled denim"
  },
  {
    id: 3,
    name: "Bamboo Fiber Dress",
    price: "$56",
    image: "https://images.unsplash.com/photo-1572804013309-59a88b7e92f1?w=400&h=500&fit=crop",
    description: "Soft, sustainable bamboo fabric"
  },
  {
    id: 4,
    name: "Hemp Canvas Tote",
    price: "$24",
    image: "https://images.unsplash.com/photo-1590874103328-eac38a683ce7?w=400&h=500&fit=crop",
    description: "Durable hemp canvas bag"
  },
  {
    id: 5,
    name: "Linen Summer Shirt",
    price: "$45",
    image: "https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?w=400&h=500&fit=crop",
    description: "Breathable natural linen"
  },
  {
    id: 6,
    name: "Organic Wool Sweater",
    price: "$78",
    image: "https://images.unsplash.com/photo-1434389677669-e08b4cac3105?w=400&h=500&fit=crop",
    description: "Ethically sourced merino wool"
  }
];

const SustainableFashion = () => {
  return (
    <div className="min-h-screen bg-background flex flex-col">
      <Header />
      
      <main className="flex-1">
        {/* Hero Section */}
        <section className="bg-gradient-subtle py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="max-w-3xl mx-auto text-center">
              <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground mb-4">
                Sustainable Fashion
              </h1>
              <p className="text-lg text-muted-foreground">
                Discover our collection of eco-friendly, ethically made clothing that looks good and does good for the planet.
              </p>
            </div>
          </div>
        </section>

        {/* Products Grid */}
        <section className="py-16 md:py-24">
          <div className="container mx-auto px-4">
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
              {products.map((product) => (
                <Card key={product.id} className="group overflow-hidden border-border hover:shadow-lift transition-all duration-300">
                  <div className="relative overflow-hidden aspect-[4/5]">
                    <img
                      src={product.image}
                      alt={product.name}
                      className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    />
                  </div>
                  <CardContent className="p-6">
                    <h3 className="text-xl font-semibold text-foreground mb-2">
                      {product.name}
                    </h3>
                    <p className="text-muted-foreground text-sm mb-3">
                      {product.description}
                    </p>
                    <p className="text-2xl font-bold text-primary">
                      {product.price}
                    </p>
                  </CardContent>
                  <CardFooter className="p-6 pt-0">
                    <Link to={`/product?id=${product.id}`} className="w-full">
                      <Button className="w-full bg-primary hover:bg-primary/90 text-primary-foreground">
                        Buy Now
                      </Button>
                    </Link>
                  </CardFooter>
                </Card>
              ))}
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
};

export default SustainableFashion;