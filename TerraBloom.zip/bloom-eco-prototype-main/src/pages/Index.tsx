import Header from "@/components/Header";
import Hero from "@/components/Hero";
import Commitment from "@/components/Commitment";
import FeaturedCollections from "@/components/FeaturedCollections";
import Community from "@/components/Community";
import Footer from "@/components/Footer";

const Index = () => {
  return (
    <div className="min-h-screen">
      <Header />
      <main>
        <Hero />
        <Commitment />
        <FeaturedCollections />
        <Community />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
