import { Button } from "@/components/ui/button";
import { Link } from "react-router-dom";
import heroImage from "@/assets/hero-sustainable-living.jpg";

const Hero = () => {
  return (
    <section className="relative w-full min-h-[600px] md:min-h-[700px] flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img
          src={heroImage}
          alt="Sustainable living with plants and nature"
          className="w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/95 via-background/70 to-background/40" />
      </div>

      {/* Content */}
      <div className="relative z-10 container mx-auto px-4 py-20">
        <div className="max-w-2xl space-y-6 animate-fade-in">
          <h1 className="text-4xl md:text-6xl lg:text-7xl font-serif font-bold text-foreground leading-tight">
            Nurturing a Sustainable Future
          </h1>
          <p className="text-lg md:text-xl text-muted-foreground max-w-xl">
            Discover handcrafted goods & eco-conscious essentials. One thoughtful product at a time.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 pt-4">
            <Link to="/collections/eco-apparel">
              <Button size="lg" className="w-full sm:w-auto font-medium shadow-soft hover:shadow-lift transition-all">
                Explore Our Collections
              </Button>
            </Link>
            <Link to="/story">
              <Button size="lg" variant="outline" className="w-full sm:w-auto font-medium">
                Learn More
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
