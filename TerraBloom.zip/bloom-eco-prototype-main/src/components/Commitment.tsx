import { Leaf, Recycle, Heart } from "lucide-react";

const commitments = [
  {
    icon: Leaf,
    title: "Ethically Sourced",
    description: "Fair trade and responsible sourcing from trusted partners worldwide.",
  },
  {
    icon: Recycle,
    title: "Eco-Friendly Materials",
    description: "Biodegradable, recycled, and renewable materials in every product.",
  },
  {
    icon: Heart,
    title: "Handcrafted Quality",
    description: "Artisan-made with care, built to last, and thoughtfully designed.",
  },
];

const Commitment = () => {
  return (
    <section className="py-20 bg-gradient-hero">
      <div className="container mx-auto px-4">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
            Our Commitment
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Every product tells a story of sustainability, quality, and conscious craftsmanship.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 md:gap-12">
          {commitments.map((item, index) => (
            <div
              key={index}
              className="flex flex-col items-center text-center space-y-4 p-6 rounded-2xl bg-card shadow-soft hover:shadow-lift transition-all duration-300 animate-fade-in"
              style={{ animationDelay: `${index * 100}ms` }}
            >
              <div className="w-16 h-16 rounded-full bg-primary/10 flex items-center justify-center">
                <item.icon className="h-8 w-8 text-primary" />
              </div>
              <h3 className="text-xl font-semibold text-foreground">{item.title}</h3>
              <p className="text-muted-foreground">{item.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Commitment;
