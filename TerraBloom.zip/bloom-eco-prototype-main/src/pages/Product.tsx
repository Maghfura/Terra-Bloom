import { useState } from "react";
import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Heart, Minus, Plus, ShoppingCart, Check } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const Product = () => {
  const [quantity, setQuantity] = useState(1);
  const [selectedImage, setSelectedImage] = useState(0);
  const [selectedSize, setSelectedSize] = useState("M");
  const [selectedColor, setSelectedColor] = useState("Natural Beige");
  const [showSuccessDialog, setShowSuccessDialog] = useState(false);

  const product = {
    name: "Organic Terracotta Planter Set",
    price: 48.00,
    description: "Handcrafted terracotta planters made by local artisans. Each piece is unique and features natural clay with a smooth finish. Perfect for indoor plants and herbs.",
    features: [
      "100% natural terracotta clay",
      "Handmade by local artisans",
      "Drainage hole included",
      "Set of 3 (small, medium, large)",
      "Biodegradable and sustainable",
    ],
    images: [
      "https://images.unsplash.com/photo-1485955900006-10f4d324d411?w=800&q=80",
      "https://images.unsplash.com/photo-1466692476868-aef1dfb1e735?w=800&q=80",
      "https://images.unsplash.com/photo-1459156212016-c812468e2115?w=800&q=80",
    ],
  };

  const handleAddToCart = () => {
    toast.success(`Added ${quantity} item(s) to cart!`);
  };

  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-12">
        {/* Breadcrumb */}
        <nav className="mb-8 text-sm text-muted-foreground">
          <Link to="/" className="hover:text-primary">Home</Link>
          <span className="mx-2">/</span>
          <Link to="/collections" className="hover:text-primary">Collections</Link>
          <span className="mx-2">/</span>
          <span className="text-foreground">Product</span>
        </nav>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
          {/* Images */}
          <div className="space-y-4">
            <div className="aspect-square rounded-2xl overflow-hidden bg-secondary shadow-soft">
              <img
                src={product.images[selectedImage]}
                alt={product.name}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="grid grid-cols-3 gap-4">
              {product.images.map((image, index) => (
                <button
                  key={index}
                  onClick={() => setSelectedImage(index)}
                  className={`aspect-square rounded-lg overflow-hidden border-2 transition-all ${
                    selectedImage === index
                      ? "border-primary shadow-soft"
                      : "border-transparent hover:border-border"
                  }`}
                >
                  <img
                    src={image}
                    alt={`${product.name} ${index + 1}`}
                    className="w-full h-full object-cover"
                  />
                </button>
              ))}
            </div>
          </div>

          {/* Product Info */}
          <div className="space-y-6">
            <div>
              <h1 className="text-3xl md:text-4xl font-serif font-bold text-foreground mb-4">
                {product.name}
              </h1>
              <div className="flex items-center gap-4 mb-6">
                <span className="text-3xl font-bold text-primary">
                  ${product.price.toFixed(2)}
                </span>
                <span className="text-sm text-muted-foreground px-3 py-1 bg-primary/10 rounded-full">
                  In Stock
                </span>
              </div>
              <p className="text-muted-foreground leading-relaxed">
                {product.description}
              </p>
            </div>

            {/* Features */}
            <div className="space-y-3">
              <h3 className="font-semibold text-foreground">Key Features:</h3>
              <ul className="space-y-2">
                {product.features.map((feature, index) => (
                  <li key={index} className="flex items-start gap-2 text-muted-foreground">
                    <span className="text-primary mt-1">•</span>
                    {feature}
                  </li>
                ))}
              </ul>
            </div>

            {/* Size Selection */}
            <div className="space-y-3 pt-4 border-t border-border">
              <Label className="text-base font-medium text-foreground">Select Size</Label>
              <RadioGroup value={selectedSize} onValueChange={setSelectedSize} className="flex gap-3">
                {["XS", "S", "M", "L", "XL", "XXL"].map((size) => (
                  <div key={size} className="relative">
                    <RadioGroupItem value={size} id={size} className="peer sr-only" />
                    <Label
                      htmlFor={size}
                      className="flex items-center justify-center w-12 h-12 border-2 border-border rounded-md cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:bg-primary/10 hover:border-primary/50"
                    >
                      <span className="text-sm font-medium">{size}</span>
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Color Selection */}
            <div className="space-y-3">
              <Label className="text-base font-medium text-foreground">Select Color</Label>
              <RadioGroup value={selectedColor} onValueChange={setSelectedColor} className="flex gap-3">
                {[
                  { name: "Natural Beige", color: "#D4C5B9" },
                  { name: "Forest Green", color: "#5C7457" },
                  { name: "Earth Brown", color: "#8B6F47" },
                  { name: "Sky Blue", color: "#87CEEB" }
                ].map((option) => (
                  <div key={option.name} className="relative">
                    <RadioGroupItem value={option.name} id={option.name} className="peer sr-only" />
                    <Label
                      htmlFor={option.name}
                      className="flex items-center justify-center w-12 h-12 border-2 border-border rounded-full cursor-pointer transition-all peer-data-[state=checked]:border-primary peer-data-[state=checked]:ring-2 peer-data-[state=checked]:ring-primary/20 hover:border-primary/50"
                      style={{ backgroundColor: option.color }}
                    >
                      {selectedColor === option.name && (
                        <Check className="h-5 w-5 text-white" />
                      )}
                    </Label>
                  </div>
                ))}
              </RadioGroup>
            </div>

            {/* Quantity & Actions */}
            <div className="space-y-4 pt-6 border-t border-border">
              <div className="flex items-center gap-4">
                <span className="text-sm font-medium text-foreground">Quantity:</span>
                <div className="flex items-center border border-border rounded-lg">
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="rounded-r-none"
                  >
                    <Minus className="h-4 w-4" />
                  </Button>
                  <span className="px-6 py-2 font-medium">{quantity}</span>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={() => setQuantity(quantity + 1)}
                    className="rounded-l-none"
                  >
                    <Plus className="h-4 w-4" />
                  </Button>
                </div>
              </div>

              <div className="flex gap-4">
                <Button
                  size="lg"
                  className="flex-1 shadow-soft hover:shadow-lift"
                  onClick={handleAddToCart}
                >
                  <ShoppingCart className="mr-2 h-5 w-5" />
                  Add to Cart
                </Button>
                <Button variant="outline" size="icon" className="w-12 h-12">
                  <Heart className="h-5 w-5" />
                </Button>
              </div>

              <Link to="/checkout" className="block">
                <Button
                  variant="outline"
                  size="lg"
                  className="w-full"
                >
                  Buy Now
                </Button>
              </Link>
            </div>

            {/* Sustainability Badge */}
            <div className="bg-primary/5 rounded-lg p-4 border border-primary/20">
              <p className="text-sm text-foreground">
                <span className="font-semibold">🌿 Sustainable Choice:</span> This product is handcrafted using eco-friendly materials and supports local artisans.
              </p>
            </div>
          </div>
        </div>
      </main>
      <Footer />

      {/* Success Dialog */}
      <Dialog open={showSuccessDialog} onOpenChange={setShowSuccessDialog}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <div className="mx-auto mb-4 flex h-16 w-16 items-center justify-center rounded-full bg-primary/10">
              <Check className="h-8 w-8 text-primary" />
            </div>
            <DialogTitle className="text-center text-2xl">Congratulations! 🎉</DialogTitle>
            <DialogDescription className="text-center text-base">
              Your order has been successfully placed!
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div className="rounded-lg bg-secondary/30 p-4 text-sm">
              <p className="text-center text-muted-foreground">
                Order confirmation will be sent to your email shortly.
              </p>
            </div>
            <div className="flex gap-3">
              <Button
                variant="outline"
                className="flex-1"
                onClick={() => setShowSuccessDialog(false)}
              >
                Continue Shopping
              </Button>
              <Link to="/" className="flex-1">
                <Button className="w-full bg-primary hover:bg-primary/90">
                  Back to Home
                </Button>
              </Link>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </div>
  );
};

export default Product;
