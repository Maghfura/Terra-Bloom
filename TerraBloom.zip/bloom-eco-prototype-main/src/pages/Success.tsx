import { Link } from "react-router-dom";
import Header from "@/components/Header";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { CheckCircle, Package, ArrowRight } from "lucide-react";

const Success = () => {
  return (
    <div className="min-h-screen bg-background">
      <Header />
      <main className="container mx-auto px-4 py-20">
        <div className="max-w-2xl mx-auto text-center space-y-8 animate-fade-in">
          {/* Success Icon */}
          <div className="flex justify-center">
            <div className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center">
              <CheckCircle className="h-12 w-12 text-primary" />
            </div>
          </div>

          {/* Heading */}
          <div className="space-y-4">
            <h1 className="text-4xl md:text-5xl font-serif font-bold text-foreground">
              Thank You!
            </h1>
            <p className="text-xl text-muted-foreground">
              Your order has been successfully placed
            </p>
          </div>

          {/* Order Details */}
          <div className="bg-card border border-border rounded-2xl p-8 shadow-soft">
            <div className="space-y-4">
              <div className="flex items-start gap-4">
                <div className="w-12 h-12 rounded-full bg-primary/10 flex items-center justify-center flex-shrink-0">
                  <Package className="h-6 w-6 text-primary" />
                </div>
                <div className="text-left flex-1">
                  <h3 className="font-semibold text-foreground mb-2">
                    Order Confirmation
                  </h3>
                  <p className="text-sm text-muted-foreground mb-1">
                    Order Number: <span className="font-medium text-foreground">#TB-2024-001</span>
                  </p>
                  <p className="text-sm text-muted-foreground">
                    A confirmation email has been sent to your inbox with tracking details.
                  </p>
                </div>
              </div>
            </div>
          </div>

          {/* What's Next */}
          <div className="bg-gradient-hero rounded-2xl p-8 text-left">
            <h3 className="text-xl font-semibold text-foreground mb-4">
              What Happens Next?
            </h3>
            <ul className="space-y-3 text-muted-foreground">
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">1.</span>
                <span>You'll receive an email confirmation with your order details</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">2.</span>
                <span>Our artisans will carefully prepare your items</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">3.</span>
                <span>You'll get shipping updates as your order makes its way to you</span>
              </li>
              <li className="flex items-start gap-3">
                <span className="text-primary font-bold mt-1">4.</span>
                <span>Enjoy your sustainable products! 🌿</span>
              </li>
            </ul>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
            <Link to="/collections" className="flex-1 sm:flex-none">
              <Button size="lg" className="w-full shadow-soft hover:shadow-lift">
                Continue Shopping
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link to="/" className="flex-1 sm:flex-none">
              <Button size="lg" variant="outline" className="w-full">
                Return to Home
              </Button>
            </Link>
          </div>

          {/* Support Note */}
          <p className="text-sm text-muted-foreground pt-8">
            Need help? <Link to="/contact" className="text-primary hover:underline">Contact our support team</Link>
          </p>
        </div>
      </main>
      <Footer />
    </div>
  );
};

export default Success;
